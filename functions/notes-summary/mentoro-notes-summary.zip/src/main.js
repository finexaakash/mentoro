/* global process */
// Appwrite Function entry point (Node.js 18+).
// Store OPENAI_API_KEY as a Function secret, never in the React .env file.
export default async ({ req, res, error }) => {
  if (req.method !== "POST") return res.json({ error: "Method not allowed" }, 405);
  let body;
  try { body = JSON.parse(req.body || "{}"); }
  catch { return res.json({ error: "Invalid JSON body" }, 400); }

  const title = String(body.title || "Untitled resource").slice(0, 200);
  const text = String(body.text || "").trim();
  if (!text) return res.json({ error: "There is no study text to summarize." }, 400);

  try {
    const openaiResponse = await fetch("https://api.openai.com/v1/responses", {
      method: "POST",
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}`, "Content-Type": "application/json" },
      body: JSON.stringify({
        model: "gpt-5-mini",
        store: false,
        instructions: "Create an accurate, student-friendly study summary. Use short headings and bullets. Include key ideas, important terms, and 3 revision questions. Only use supplied text; say when information is missing.",
        input: `Resource title: ${title}\n\nStudy text:\n${text.slice(0, 12000)}`,
      }),
    });
    const data = await openaiResponse.json();
    if (!openaiResponse.ok) {
      error(data.error?.message || "OpenAI request failed");
      return res.json({ error: "The AI service is temporarily unavailable." }, 502);
    }
    return res.json({ summary: data.output_text });
  } catch (err) {
    error(err.message);
    return res.json({ error: "Could not create the summary." }, 500);
  }
};
